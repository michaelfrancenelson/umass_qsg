### R code from vignette source 'IntroductionSweaveFile.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: IntroductionSweaveFile.Rnw:92-93
###################################################
number.species<-137


###################################################
### code chunk number 2: IntroductionSweaveFile.Rnw:100-104
###################################################
pi<-3.14159
small.value<-1.0e-10
species.name<-'American robin'
conifer<-TRUE


###################################################
### code chunk number 3: IntroductionSweaveFile.Rnw:111-112
###################################################
#species.name+37


###################################################
### code chunk number 4: IntroductionSweaveFile.Rnw:133-134
###################################################
demo.vector1<-c(1,4,2,6,12)


###################################################
### code chunk number 5: IntroductionSweaveFile.Rnw:141-142
###################################################
demo.vector1[4] #the fourth element of demo.vector, 6


###################################################
### code chunk number 6: IntroductionSweaveFile.Rnw:149-150
###################################################
demo.vector2<-c(4,2,1,2,4)


###################################################
### code chunk number 7: IntroductionSweaveFile.Rnw:155-156
###################################################
demo.matrix<-cbind(demo.vector1,demo.vector2)


###################################################
### code chunk number 8: IntroductionSweaveFile.Rnw:161-162
###################################################
demo.matrix[4,2] #row 4, column 2 in matrix demo.matrix


###################################################
### code chunk number 9: IntroductionSweaveFile.Rnw:167-168
###################################################
demo.matrix[,2] #second column of matrix demo.matrix


###################################################
### code chunk number 10: IntroductionSweaveFile.Rnw:175-176
###################################################
demo.matrix[5,] #row 5 of matrix demo.matrix


###################################################
### code chunk number 11: IntroductionSweaveFile.Rnw:183-187
###################################################
demo.matrix[] #all rows and columns of matrix demo.matrix
demo.vector1[1:3] #demo.vector1[1] through demo.vector1[3]
demo.vector1[-1] #all of vector demo.vector1 except demo.vector[1]
demo.matrix[1:3,2] #a submatrix of demo.matrix from row 1 to 3 and column 2


###################################################
### code chunk number 12: IntroductionSweaveFile.Rnw:192-193
###################################################
demo.matrix[c(1,2,5),2] #a submatrix consisting of rows 1,2 and 5, and columns


###################################################
### code chunk number 13: IntroductionSweaveFile.Rnw:199-200
###################################################
birds<-read.csv('c:/work/qsg/tutorials/introduction/birds.csv',header=TRUE)


###################################################
### code chunk number 14: IntroductionSweaveFile.Rnw:207-208
###################################################
birds$AMRO


###################################################
### code chunk number 15: IntroductionSweaveFile.Rnw:213-214
###################################################
attach(birds)


###################################################
### code chunk number 16: IntroductionSweaveFile.Rnw:219-220
###################################################
AMRO


###################################################
### code chunk number 17: IntroductionSweaveFile.Rnw:227-228
###################################################
detach(birds)


###################################################
### code chunk number 18: IntroductionSweaveFile.Rnw:236-239
###################################################
list.demo<-list(demo.vector1,names(birds))  #creates a list from the two components
names(list.demo)<-c('species per plot','field names') #assigns names to the two components
list.demo #prints the list to the console


###################################################
### code chunk number 19: IntroductionSweaveFile.Rnw:249-250
###################################################
str(birds)


###################################################
### code chunk number 20: IntroductionSweaveFile.Rnw:257-258
###################################################
head(birds,10)


###################################################
### code chunk number 21: IntroductionSweaveFile.Rnw:263-264
###################################################
fix(birds)


###################################################
### code chunk number 22: IntroductionSweaveFile.Rnw:273-274
###################################################
max(birds[,5])


###################################################
### code chunk number 23: IntroductionSweaveFile.Rnw:279-280
###################################################
max(birds$AMRO)


###################################################
### code chunk number 24: IntroductionSweaveFile.Rnw:285-286
###################################################
sum(birds[,5])


###################################################
### code chunk number 25: IntroductionSweaveFile.Rnw:291-292
###################################################
log(birds[,4:10]+1)


###################################################
### code chunk number 26: IntroductionSweaveFile.Rnw:310-311
###################################################
sum(birds[,5]>1)


###################################################
### code chunk number 27: IntroductionSweaveFile.Rnw:316-317
###################################################
sum(birds[,5][birds[,5]>1])


###################################################
### code chunk number 28: IntroductionSweaveFile.Rnw:322-323
###################################################
max(birds[,5][birds$BHGR==5])


###################################################
### code chunk number 29: IntroductionSweaveFile.Rnw:331-332
###################################################
x<-birds[,4]


###################################################
### code chunk number 30: IntroductionSweaveFile.Rnw:337-338
###################################################
y<-x[!is.na(x)]


###################################################
### code chunk number 31: IntroductionSweaveFile.Rnw:343-344
###################################################
is.na(x)


###################################################
### code chunk number 32: IntroductionSweaveFile.Rnw:349-350
###################################################
!is.na(x)


###################################################
### code chunk number 33: IntroductionSweaveFile.Rnw:355-356
###################################################
x[!is.na(x)]


###################################################
### code chunk number 34: IntroductionSweaveFile.Rnw:361-362
###################################################
x[x!='NA']


###################################################
### code chunk number 35: IntroductionSweaveFile.Rnw:369-370
###################################################
na.omit(x)


###################################################
### code chunk number 36: IntroductionSweaveFile.Rnw:379-384
###################################################
birds.new<-birds[,4:10] #select all rows and columns 4 through 10
birds.new<-birds[,-c(1:3)] #same
birds.new<-subset(birds,select=AMGO:BHGR) #same
birds.new<-birds[,c(4,5,10)] #select all rows and columns 4,5 and 10
birds.new<-subset(birds,select=c(AMGO,AMRO,BHGR)) #same


###################################################
### code chunk number 37: IntroductionSweaveFile.Rnw:389-395
###################################################
birds.new<-birds[1:4,] #select rows 1 through 4 and all columns
birds.new<-birds[-c(5:10),] #same
birds.new<-birds[c(4,5,10),] #select rows 4,5 and 10 and all columns
birds.new<-subset(birds,subset=SUB=='AL') #select all rows where SUB=='AL'
birds.new<-subset(birds,subset=BLOCK>10)  #select all rows where BLOCK>10
birds.new<-subset(birds,subset=BLOCK>10&SUB=='AL') #select rows meeting both criteria


###################################################
### code chunk number 38: IntroductionSweaveFile.Rnw:404-405
###################################################
(bird.max<-apply(birds[,4:10],2,max))


###################################################
### code chunk number 39: IntroductionSweaveFile.Rnw:412-413
###################################################
(bird.max<-apply(birds[,4:10],2,max,na.rm=TRUE))


###################################################
### code chunk number 40: IntroductionSweaveFile.Rnw:426-427
###################################################
(bird.sum<-apply(birds[,4:10],1,sum,na.rm=TRUE))


###################################################
### code chunk number 41: IntroductionSweaveFile.Rnw:434-435
###################################################
(bird.sum<-apply(birds[,4:10]>0,2,sum,na.rm=TRUE))


###################################################
### code chunk number 42: IntroductionSweaveFile.Rnw:452-453
###################################################
sum(birds[,4:10])


###################################################
### code chunk number 43: IntroductionSweaveFile.Rnw:458-459
###################################################
sum(birds[,4:10],na.rm=TRUE)


###################################################
### code chunk number 44: IntroductionSweaveFile.Rnw:470-472
###################################################
apply(X=birds[,4:10],MARGIN=2,FUN=sum)
apply(birds[,4:10],2,sum)


###################################################
### code chunk number 45: IntroductionSweaveFile.Rnw:479-480
###################################################
apply(birds[,4:10],2,sum,na.rm=TRUE)


###################################################
### code chunk number 46: IntroductionSweaveFile.Rnw:485-486
###################################################
apply(birds[,4:10],FUN=sum,MARGIN=2,na.rm=TRUE)


###################################################
### code chunk number 47: IntroductionSweaveFile.Rnw:510-511
###################################################
birds<-read.table('c:/work/stats/ecodata/lab/R.intro/birds.dat',header=TRUE)


###################################################
### code chunk number 48: IntroductionSweaveFile.Rnw:516-517
###################################################
setwd('c:/work/qsg/tutorials/introduction/')


###################################################
### code chunk number 49: IntroductionSweaveFile.Rnw:536-537
###################################################
birds<-read.table('birds.csv',header=TRUE,sep=',')


###################################################
### code chunk number 50: IntroductionSweaveFile.Rnw:542-543
###################################################
birds<-read.csv('birds.csv',header=TRUE)


###################################################
### code chunk number 51: IntroductionSweaveFile.Rnw:560-561
###################################################
birds$BLOCK<-as.factor(birds$BLOCK)


###################################################
### code chunk number 52: IntroductionSweaveFile.Rnw:566-567
###################################################
str(birds)


###################################################
### code chunk number 53: IntroductionSweaveFile.Rnw:576-577
###################################################
write.table(birds,'out.csv',row.names=FALSE,sep=',')


###################################################
### code chunk number 54: IntroductionSweaveFile.Rnw:582-583
###################################################
write.table(birds,'c:/work/stats/ecodata/lab/R.intro/out.csv',row.names=FALSE,sep=',')


###################################################
### code chunk number 55: IntroductionSweaveFile.Rnw:598-599
###################################################
?Devices


###################################################
### code chunk number 56: IntroductionSweaveFile.Rnw:603-604
###################################################
help(Devices)


###################################################
### code chunk number 57: IntroductionSweaveFile.Rnw:611-612
###################################################
x<-1:50


###################################################
### code chunk number 58: IntroductionSweaveFile.Rnw:617-618
###################################################
y<-rnorm(50,0,1)


###################################################
### code chunk number 59: IntroductionSweaveFile.Rnw:626-627
###################################################
plot(x,y)


###################################################
### code chunk number 60: IntroductionSweaveFile.Rnw:636-643
###################################################
par(mfrow=c(3,2))#defined below
plot(x,y,type='o') #to change the type of plot, try type='l','o','b', and 's'
plot(x,y,type='o',lty=2) #to change the line type try lty=2,3,4,...
plot(x,y,type='o',col='blue') #to change the line color try col='blue','red','green', ...
plot(x,y,type='o',pch=2) #to change the point symbols try pch=2,3,4,...
plot(x,y,type='o',cex=2) #to change the point size try cex=2,3,4,... (#x normal)
plot(x,y,type='o',lwd=2) #to change the line width try lwd=2,3,4,... (#x normal)


###################################################
### code chunk number 61: IntroductionSweaveFile.Rnw:649-650
###################################################
help(par)


###################################################
### code chunk number 62: IntroductionSweaveFile.Rnw:655-658
###################################################
par(mfrow=c(2,3)) #partitions the page into 6 sections, 2 rows and 3 columns.
par(new=TRUE) #used to overlay different plot types
par(mai=c(0.6,0.5,0.1,0.5)) #specifies margin size in inches (bottom, left, top, right)


###################################################
### code chunk number 63: IntroductionSweaveFile.Rnw:663-664
###################################################
par(mfrow=c(2,3),new=TRUE,mai=c(0.6,0.5,0.1,0.5))


###################################################
### code chunk number 64: IntroductionSweaveFile.Rnw:704-705
###################################################
help(mahalanobis)


###################################################
### code chunk number 65: IntroductionSweaveFile.Rnw:710-711
###################################################
?mahalanobis


###################################################
### code chunk number 66: IntroductionSweaveFile.Rnw:716-717
###################################################
help.search('mahalanobis distance')


###################################################
### code chunk number 67: IntroductionSweaveFile.Rnw:722-723
###################################################
??'mahalanobis distance' 


###################################################
### code chunk number 68: IntroductionSweaveFile.Rnw:730-731
###################################################
RSiteSearch('mahalanobis distance')


###################################################
### code chunk number 69: IntroductionSweaveFile.Rnw:748-749
###################################################
library(MASS)


###################################################
### code chunk number 70: IntroductionSweaveFile.Rnw:756-757
###################################################
library()


