### R code from vignette source 'DataManipulation.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: DataManipulation.Rnw:52-57
###################################################
library(sampling)
library(car)
library(chron)
library(plotrix)
library(reshape)


###################################################
### code chunk number 2: DataManipulation.Rnw:62-63
###################################################
setwd('c:/work/qsg/tutorials/data manipulations/')


###################################################
### code chunk number 3: DataManipulation.Rnw:73-74
###################################################
(a<-round(rnorm(30,0,10),2))


###################################################
### code chunk number 4: DataManipulation.Rnw:80-81
###################################################
hist(a)


###################################################
### code chunk number 5: DataManipulation.Rnw:90-91
###################################################
(b<-gl(6,5,labels=c('A','B','C','D','E','F')))


###################################################
### code chunk number 6: DataManipulation.Rnw:96-100
###################################################
rep(1:4,times=2)
rep(1:4,each=2)     
rep(1:4,c(2,1,2,1))
rep(1:4,each=2,len=10)  


###################################################
### code chunk number 7: DataManipulation.Rnw:107-109
###################################################
seq(1,9) 
seq(1,9,by=2) 


###################################################
### code chunk number 8: DataManipulation.Rnw:116-119
###################################################
ABdata1<-cbind(a,b)
head(ABdata1)
str(ABdata1)


###################################################
### code chunk number 9: DataManipulation.Rnw:126-130
###################################################
b<-as.character(b)
ABdata1<-cbind(a,b)
head(ABdata1)
str(ABdata1)


###################################################
### code chunk number 10: DataManipulation.Rnw:135-137
###################################################
ABdata1<-as.data.frame(ABdata1) 
str(ABdata1)


###################################################
### code chunk number 11: DataManipulation.Rnw:142-144
###################################################
ABdata1[,1]<-as.numeric(ABdata1[,1])
str(ABdata1)


###################################################
### code chunk number 12: DataManipulation.Rnw:151-157
###################################################
b<-as.character(b)
ABdata<-cbind(a,b)
ABdata<-as.data.frame(ABdata)
ABdata[,1]<-as.numeric(as.character(ABdata[,1]))
str(ABdata)
head(ABdata)


###################################################
### code chunk number 13: DataManipulation.Rnw:164-166
###################################################
colnames(ABdata)<-c("Var1","Var2")
head(ABdata)


###################################################
### code chunk number 14: DataManipulation.Rnw:173-176
###################################################
vector1<-runif(10,min=0,max=1)
vector2<-runif(10,min=10,max=20)
(ABdata2<-rbind(vector1,vector2))


###################################################
### code chunk number 15: DataManipulation.Rnw:187-189
###################################################
sort(a)
sort(a,decreasing=TRUE)


###################################################
### code chunk number 16: DataManipulation.Rnw:194-195
###################################################
ABdata[order(ABdata$Var1),]


###################################################
### code chunk number 17: DataManipulation.Rnw:200-201
###################################################
order(ABdata$Var1)


###################################################
### code chunk number 18: DataManipulation.Rnw:208-209
###################################################
ABdata[order(ABdata$Var2,ABdata$Var1),]


###################################################
### code chunk number 19: DataManipulation.Rnw:217-220
###################################################
ABdata$habitat<-recode(ABdata$Var2,"c('A','B')='scrub' ; 
  c('C')='pine forest' ;  c('D','E','F')='oak forest'")
ABdata


###################################################
### code chunk number 20: DataManipulation.Rnw:227-231
###################################################
ABdata$Var1PN<-NULL
ABdata$Var1PN[ABdata$Var1>=0]<-"positive"
ABdata$Var1PN[ABdata$Var1<0]<-"negative"
head(ABdata)


###################################################
### code chunk number 21: DataManipulation.Rnw:244-245
###################################################
ABdata$habitat %in% c('pine forest','oak forest')


###################################################
### code chunk number 22: DataManipulation.Rnw:252-253
###################################################
which(ABdata$habitat %in% c('pine forest','oak forest'))


###################################################
### code chunk number 23: DataManipulation.Rnw:258-259
###################################################
any(ABdata$habitat %in% c('pine forest','oak forest'))


###################################################
### code chunk number 24: DataManipulation.Rnw:264-265
###################################################
all(ABdata$habitat %in% c('pine forest','oak forest'))


###################################################
### code chunk number 25: DataManipulation.Rnw:272-273
###################################################
unique(ABdata$habitat)


###################################################
### code chunk number 26: DataManipulation.Rnw:278-279
###################################################
duplicated(ABdata$habitat)


###################################################
### code chunk number 27: DataManipulation.Rnw:284-285
###################################################
ABdata[!duplicated(ABdata$habitat),]


###################################################
### code chunk number 28: DataManipulation.Rnw:292-294
###################################################
table(ABdata$habitat)
table(ABdata$habitat,ABdata$Var1PN)


###################################################
### code chunk number 29: DataManipulation.Rnw:299-302
###################################################
table1<-table(ABdata$habitat,ABdata$Var1PN)
tableDF<-as.data.frame.matrix(table1)
str(tableDF)


###################################################
### code chunk number 30: DataManipulation.Rnw:307-310
###################################################
round(prop.table(table1),2)
round(prop.table(table1,margin=1),2)
round(prop.table(table1,margin=2),2)


###################################################
### code chunk number 31: DataManipulation.Rnw:317-321
###################################################
tapply(ABdata$Var1,ABdata$habitat,mean)
tapply(ABdata$Var1,ABdata$habitat,sd)
tapply(ABdata$Var1,ABdata$habitat,std.error)
tapply(ABdata$Var1,ABdata$habitat,length)


###################################################
### code chunk number 32: DataManipulation.Rnw:332-333
###################################################
aggregate(ABdata$Var1,by=list(ABdata$Var1PN,ABdata$habitat),mean)


###################################################
### code chunk number 33: DataManipulation.Rnw:349-350
###################################################
sample(ABdata$Var1,size=5,replace=TRUE)


###################################################
### code chunk number 34: DataManipulation.Rnw:355-356
###################################################
ABdata[sample(1:nrow(ABdata),size=5,replace=TRUE),]


###################################################
### code chunk number 35: DataManipulation.Rnw:363-366
###################################################
strat.output<-strata(ABdata,stratanames=NULL,size=5,method='srswr')
strat.output
getdata(ABdata,strat.output)


###################################################
### code chunk number 36: DataManipulation.Rnw:373-378
###################################################
ABdata<-ABdata[order(ABdata$Var2),]
number.levels<-length(unique(ABdata$Var2))
strat.output2<-strata(ABdata,stratanames='Var2',
  size=rep(2,number.levels),method='srswr')
getdata(ABdata,strat.output2)


###################################################
### code chunk number 37: DataManipulation.Rnw:387-390
###################################################
strat.output3<-strata(ABdata,stratanames='Var2',
  size=c(2,3,4,1,2,3),method='srswr')
getdata(ABdata,strat.output3)


###################################################
### code chunk number 38: DataManipulation.Rnw:402-404
###################################################
ABdata$UniqueID<-seq(1,30)
head(ABdata)


###################################################
### code chunk number 39: DataManipulation.Rnw:409-411
###################################################
data2<-read.csv('DataToMerge.csv')
str(data2)


###################################################
### code chunk number 40: DataManipulation.Rnw:420-424
###################################################
colnames(ABdata)
colnames(data2)
merged.data<-merge(x=ABdata,y=data2,by.x="UniqueID",by.y="UniqID")
head(merged.data)


###################################################
### code chunk number 41: DataManipulation.Rnw:431-433
###################################################
sort(intersect(merged.data$UniqueID,ABdata$UniqueID))
sort(intersect(merged.data$UniqueID,data2$UniqID))


###################################################
### code chunk number 42: DataManipulation.Rnw:440-442
###################################################
setequal(merged.data$UniqueID,ABdata$UniqueID)
setequal(merged.data$UniqueID,data2$UniqID)


###################################################
### code chunk number 43: DataManipulation.Rnw:447-449
###################################################
setdiff(ABdata$UniqueID,merged.data$UniqueID)
setdiff(data2$UniqID,merged.data$UniqueID)


###################################################
### code chunk number 44: DataManipulation.Rnw:456-458
###################################################
merged.data2<-merge(x=ABdata,y=data2,by.x="UniqueID",by.y="UniqID",all=TRUE)
tail(merged.data2,10)


###################################################
### code chunk number 45: DataManipulation.Rnw:472-474
###################################################
dataDT<-read.csv('DateTimeEx.csv',header=TRUE)
str(dataDT)


###################################################
### code chunk number 46: DataManipulation.Rnw:481-483
###################################################
dataDT$Date<-as.character(dataDT$Date)
str(dataDT)


###################################################
### code chunk number 47: DataManipulation.Rnw:488-491
###################################################
dataDT$Date2<-chron(dataDT$Date,format="day-month-year") 
head(dataDT$Date2)
str(dataDT)


###################################################
### code chunk number 48: DataManipulation.Rnw:496-497
###################################################
dataDT$Date2[1]


###################################################
### code chunk number 49: DataManipulation.Rnw:502-503
###################################################
hist(dataDT$Date2)


###################################################
### code chunk number 50: DataManipulation.Rnw:508-510
###################################################
dataDT$Month<-cut(dataDT$Date2,"month")
str(dataDT)


###################################################
### code chunk number 51: DataManipulation.Rnw:515-518
###################################################
dataDT$Month<-as.character(dataDT$Month)
dataDT$Month<-as.factor(dataDT$Month)
str(dataDT)


###################################################
### code chunk number 52: DataManipulation.Rnw:523-528
###################################################
dataDT$Day<-cut(dataDT$Date2,"day")
dataDT$Day<-as.numeric(dataDT$Day)
str(dataDT)
tail(dataDT$Day)
min(dataDT$Date2)


###################################################
### code chunk number 53: DataManipulation.Rnw:535-538
###################################################
dataDT$OrdinalDay<-dataDT$Day+304
head(dataDT$OrdinalDay)
head(dataDT$Date2)


###################################################
### code chunk number 54: DataManipulation.Rnw:543-545
###################################################
dataD2<-read.csv('DateEx2.csv',header=TRUE)
str(dataD2)


###################################################
### code chunk number 55: DataManipulation.Rnw:552-555
###################################################
dataD2$Date<-as.character(dataD2$Date)
dataD2$Date2<-chron(dataD2$Date,format="day-month-year") 
hist(dataD2$Date2)


###################################################
### code chunk number 56: DataManipulation.Rnw:562-565
###################################################
dataD2$Day<-cut(dataD2$Date2,"day")
dataD2$Day<-as.numeric(dataD2$Day)
hist(dataD2$Day)


###################################################
### code chunk number 57: DataManipulation.Rnw:570-571
###################################################
dataD2$Day[which(dataD2$Year==2013)]<-dataD2$Day[which(dataD2$Year==2013)]-365


###################################################
### code chunk number 58: DataManipulation.Rnw:578-579
###################################################
hist(dataD2$Day)


###################################################
### code chunk number 59: DataManipulation.Rnw:586-587
###################################################
(dataDT$Time<-as.character(dataDT$Time))


###################################################
### code chunk number 60: DataManipulation.Rnw:594-597
###################################################
dataDT$Time[(nchar(dataDT$Time)==7)]<-
  paste("0",dataDT$Time[(nchar(dataDT$Time)==7)],sep="")
head(dataDT$Time)


###################################################
### code chunk number 61: DataManipulation.Rnw:616-619
###################################################
dataDT$Time1<-chron(times=dataDT$Time)
str(dataDT)
head(dataDT$Time1)


###################################################
### code chunk number 62: DataManipulation.Rnw:624-626
###################################################
dataDT$Hour<-hours(dataDT$Time1)
head(dataDT)


###################################################
### code chunk number 63: DataManipulation.Rnw:640-642
###################################################
GCKIdata<-read.csv('GCKIdata.csv',header=TRUE)
str(GCKIdata)


###################################################
### code chunk number 64: DataManipulation.Rnw:657-659
###################################################
head(GCKIdata,10)
summary(GCKIdata)


###################################################
### code chunk number 65: DataManipulation.Rnw:668-673
###################################################
GCKIdataWide<-reshape(data=GCKIdata,timevar='visit',idvar=c('basin','sub','sta'),
    direction='wide',v.names=c('date','obs','cloud','wind','GCKI'))
head(GCKIdataWide)
tail(GCKIdataWide)
str(GCKIdataWide)


###################################################
### code chunk number 66: DataManipulation.Rnw:694-695
###################################################
summary(GCKIdataWide)


###################################################
### code chunk number 67: DataManipulation.Rnw:702-706
###################################################
GCKIdataLong<-reshape(data=GCKIdataWide,timevar='visit',
  idvar=c('basin','sub','sta'),direction='long',
  v.names=c('date','obs','cloud','wind','GCKI'))
head(GCKIdataLong)


###################################################
### code chunk number 68: DataManipulation.Rnw:723-724
###################################################
names(GCKIdata)<-tolower(names(GCKIdata))


###################################################
### code chunk number 69: DataManipulation.Rnw:729-732
###################################################
GCKIdataMelted<-melt(GCKIdata,id.vars=c("visit","basin","sub", "sta","year"))
head(GCKIdataMelted)
tail(GCKIdataMelted)


###################################################
### code chunk number 70: DataManipulation.Rnw:739-742
###################################################
GCKIdataLongest<-melt(GCKIdata)
head(GCKIdataLongest)
tail(GCKIdataLongest)


###################################################
### code chunk number 71: DataManipulation.Rnw:749-752
###################################################
GCKIdataCasted<-cast(GCKIdataMelted,
  formula=basin + sub + sta + year ~ visit + variable)
head(GCKIdataCasted)


###################################################
### code chunk number 72: DataManipulation.Rnw:759-760
###################################################
summary(GCKIdataCasted)


###################################################
### code chunk number 73: DataManipulation.Rnw:767-768
###################################################
str(GCKIdataCasted)


###################################################
### code chunk number 74: DataManipulation.Rnw:773-775
###################################################
GCKIdataCastedDF<-as.data.frame.matrix(GCKIdataCasted)
str(GCKIdataCastedDF)


###################################################
### code chunk number 75: DataManipulation.Rnw:784-785
###################################################
cast(GCKIdataMelted,formula= . ~ variable,fun.aggregate=mean,na.rm=TRUE)


###################################################
### code chunk number 76: DataManipulation.Rnw:792-793
###################################################
cast(GCKIdataMelted,formula= visit ~ variable,fun.aggregate=mean,na.rm=TRUE)


###################################################
### code chunk number 77: DataManipulation.Rnw:798-799
###################################################
cast(GCKIdataMelted,formula= variable ~ visit,fun.aggregate=summary,na.rm=TRUE)


###################################################
### code chunk number 78: DataManipulation.Rnw:804-805
###################################################
head(cast(GCKIdataMelted,formula= basin + sub +sta ~ variable,fun.aggregate=mean,na.rm=TRUE))


