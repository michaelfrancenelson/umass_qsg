### R code from vignette source 'LinearSweaveFile.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: LinearSweaveFile.Rnw:72-81
###################################################
library(car)
library(epiR)
library(hier.part)
library(Hmisc)
library(MASS)
library(MuMIn)
library(permute)
library(vegan)
library(VGAM)


###################################################
### code chunk number 2: LinearSweaveFile.Rnw:95-96
###################################################
source('c:/work/R/functions/biostats.R')


###################################################
### code chunk number 3: LinearSweaveFile.Rnw:105-107
###################################################
setwd('c:/work/qsg/tutorials/linear regression/')
birds<-read.csv('birds.csv',header=TRUE)


###################################################
### code chunk number 4: LinearSweaveFile.Rnw:115-116
###################################################
str(birds)


###################################################
### code chunk number 5: LinearSweaveFile.Rnw:145-146
###################################################
summary(birds)


###################################################
### code chunk number 6: LinearSweaveFile.Rnw:156-158
###################################################
boxplot(birds$BRCR,horizontal=TRUE,col='gray',xlab='BRCR',
     main='Boxplot of BRCR')


###################################################
### code chunk number 7: LinearSweaveFile.Rnw:161-162
###################################################
hist(birds$BRCR,col='gray',xlab='BRCR',main='Histogram of BRCR')


###################################################
### code chunk number 8: LinearSweaveFile.Rnw:176-177
###################################################
pairs(birds[4:15],lower.panel=panel.smooth,upper.panel=panel.cor)


###################################################
### code chunk number 9: LinearSweaveFile.Rnw:182-183
###################################################
round(cor(birds[4:15]),2)


###################################################
### code chunk number 10: LinearSweaveFile.Rnw:188-191
###################################################
cory<-round(cor(birds[4:15]),2)
cory[abs(cory)<0.5]<-NA
cory


###################################################
### code chunk number 11: LinearSweaveFile.Rnw:199-201
###################################################
plot(birds$ls,birds$po)
plsmo(x=birds$ls,y=birds$po,method='lowess',add=TRUE,trim=0)


###################################################
### code chunk number 12: LinearSweaveFile.Rnw:211-215
###################################################
fit.full<-lm(BRCR~sub.lat + sub.long + sub.elev + road.den + 
     stream.den + p.mps + s.mps + s.contag + cf + ls + po + sa,data=birds)
vif(fit.full)
1/vif(fit.full) #tolerance


###################################################
### code chunk number 13: LinearSweaveFile.Rnw:222-227
###################################################
names(birds)
birds<-birds[,-14]
fit.full<-lm(BRCR ~ sub.lat + sub.long + sub.elev + road.den + 
  stream.den + p.mps + s.mps + s.contag + cf + ls + sa,data=birds)
vif(fit.full)


###################################################
### code chunk number 14: LinearSweaveFile.Rnw:243-244
###################################################
pairs(birds[,c('ls','BRCR')],lower.panel=panel.smooth,upper.panel=panel.cor)


###################################################
### code chunk number 15: LinearSweaveFile.Rnw:251-255
###################################################
plot(birds$ls,birds$BRCR)
plsmo(x=birds$ls,y=birds$BRCR,method='lowess',add=TRUE,f=0.5,trim=0)
plsmo(x=birds$ls,y=birds$BRCR,method='lowess',add=TRUE,f=0.9,trim=0,lty=2)
legend('topleft',legend=c('f=0.5','f=0.9'),lty=c(1,2),bty='n')


###################################################
### code chunk number 16: LinearSweaveFile.Rnw:268-270
###################################################
fit1<-lm(BRCR ~ ls + stream.den + sub.lat + s.contag,data=birds)
fit1


###################################################
### code chunk number 17: LinearSweaveFile.Rnw:279-280
###################################################
avPlots(fit1)


###################################################
### code chunk number 18: LinearSweaveFile.Rnw:302-303
###################################################
vif(fit1)


###################################################
### code chunk number 19: LinearSweaveFile.Rnw:310-313
###################################################
par(mfrow=c(2,2)) 
plot(fit1)
par(mfrow=c(1,1))


###################################################
### code chunk number 20: LinearSweaveFile.Rnw:330-331
###################################################
summary(influence.measures(fit1))


###################################################
### code chunk number 21: LinearSweaveFile.Rnw:346-347
###################################################
lm(BRCR~ls + stream.den + sub.lat + s.contag,data=birds[-14,])


###################################################
### code chunk number 22: LinearSweaveFile.Rnw:359-360
###################################################
summary(fit1)


###################################################
### code chunk number 23: LinearSweaveFile.Rnw:377-379
###################################################
confint(fit1)
confint(fit1,level=.99)


###################################################
### code chunk number 24: LinearSweaveFile.Rnw:415-416
###################################################
logLik(fit1)


###################################################
### code chunk number 25: LinearSweaveFile.Rnw:429-430
###################################################
AIC(fit1)


###################################################
### code chunk number 26: LinearSweaveFile.Rnw:443-460
###################################################
fit.null<-lm(BRCR~1,data=birds)

fit.a<-lm(BRCR~sub.lat,data=birds)
fit.b<-lm(BRCR~sub.long,data=birds)
fit.c<-lm(BRCR~sub.elev,data=birds)
fit.d<-lm(BRCR~road.den,data=birds)
fit.e<-lm(BRCR~stream.den,data=birds)
fit.f<-lm(BRCR~p.mps,data=birds)
fit.g<-lm(BRCR~s.mps,data=birds)
fit.h<-lm(BRCR~s.contag,data=birds)
fit.i<-lm(BRCR~cf,data=birds)
fit.j<-lm(BRCR~ls,data=birds)
fit.k<-lm(BRCR~sa,data=birds)

fit1.AIC<-AIC(fit.null,fit.a,fit.b,fit.c,fit.d,fit.e,fit.f,fit.g,fit.h,
     fit.i,fit.j,fit.k)
fit1.AIC[order(fit1.AIC[,2]),]


###################################################
### code chunk number 27: LinearSweaveFile.Rnw:467-476
###################################################
fit.a2<-lm(BRCR~ls + s.mps,data=birds)
fit.b2<-lm(BRCR~ls + p.mps,data=birds)
fit.c2<-lm(BRCR~ls + stream.den,data=birds)
fit.d2<-lm(BRCR~ls + s.contag,data=birds)
fit.e2<-lm(BRCR~ls + sub.lat,data=birds)
fit.f2<-lm(BRCR~ls + sa,data=birds)

fit2.AIC<-AIC(fit.j,fit.a2,fit.b2,fit.c2,fit.d2,fit.e2,fit.f2)
fit2.AIC[order(fit2.AIC[,2]),]


###################################################
### code chunk number 28: LinearSweaveFile.Rnw:481-504
###################################################
fit.a3<-lm(BRCR~ls + stream.den + sub.lat,data=birds)
fit.b3<-lm(BRCR~ls + stream.den + s.contag,data=birds)
fit.c3<-lm(BRCR~ls + stream.den + p.mps,data=birds)
fit.d3<-lm(BRCR~ls + stream.den + s.mps,data=birds)
fit.e3<-lm(BRCR~ls + stream.den + sa,data=birds)

fit3.AIC<-AIC(fit.c2,fit.a3,fit.b3,fit.c3,fit.d3,fit.e3)
fit3.AIC[order(fit3.AIC[,2]),]

fit.a4<-lm(BRCR~ls + stream.den + sub.lat + s.contag,data=birds)
fit.c4<-lm(BRCR~ls + stream.den + sub.lat + sa,data=birds)
fit.b4<-lm(BRCR~ls + stream.den + sub.lat + s.mps,data=birds)
fit.d4<-lm(BRCR~ls + stream.den + sub.lat + p.mps,data=birds)

fit4.AIC<-AIC(fit.a3,fit.a4,fit.b4,fit.c4,fit.d4)
fit4.AIC[order(fit4.AIC[,2]),]

fit.a5<-lm(BRCR~ls + stream.den + sub.lat + s.contag + sa,data=birds)
fit.b5<-lm(BRCR~ls + stream.den + sub.lat + s.contag + s.mps,data=birds)
fit.c5<-lm(BRCR~ls + stream.den + sub.lat + s.contag + p.mps,data=birds)

fit5.AIC<-AIC(fit.a4,fit.a5,fit.b5,fit.c5)
fit5.AIC[order(fit5.AIC[,2]),]


###################################################
### code chunk number 29: LinearSweaveFile.Rnw:511-513
###################################################
compare.AIC<-AIC(fit.null,fit.j,fit.c2,fit.a3,fit.a4)
compare.AIC[order(compare.AIC[,2]),]


###################################################
### code chunk number 30: LinearSweaveFile.Rnw:524-527
###################################################
fit.a7<-lm(BRCR~ls + stream.den + sub.lat + s.contag + sa + p.mps + s.mps,
     data=birds)
summary(fit.a7)


###################################################
### code chunk number 31: LinearSweaveFile.Rnw:540-542
###################################################
test<-step(lm(BRCR~sub.lat + sub.long + sub.elev + road.den + stream.den
     + p.mps + s.mps + s.contag + cf + ls + sa,data=birds))


###################################################
### code chunk number 32: LinearSweaveFile.Rnw:551-555
###################################################
model.full<-lm(BRCR~sub.lat + sub.long + sub.elev + road.den + stream.den
     + p.mps + s.mps + s.contag + cf + ls + sa,data=birds)
step(lm(BRCR~1,data=birds),scope=list(lower=~1,upper=model.full),
     direction='forward')


###################################################
### code chunk number 33: LinearSweaveFile.Rnw:562-564
###################################################
step(lm(BRCR~sub.lat + sub.long + sub.elev + road.den + stream.den + 
  p.mps + s.mps + s.contag + cf + ls + sa,data=birds),scope=list(lower=~1,upper=model.full))


###################################################
### code chunk number 34: LinearSweaveFile.Rnw:578-580
###################################################
y<-birds$BRCR
x<-birds[,4:14]


###################################################
### code chunk number 35: LinearSweaveFile.Rnw:584-586
###################################################
allsub<-all.subsets.glm(birds$BRCR,birds[,4:14],family=gaussian,maxp=11,varimp=TRUE)
allsub$model.statistics


###################################################
### code chunk number 36: LinearSweaveFile.Rnw:596-597
###################################################
allsub$variable.importance


###################################################
### code chunk number 37: LinearSweaveFile.Rnw:612-614
###################################################
birds.std<-data.stand(birds,method='standardize',var='sub.lat:sa',plot=FALSE) 
head(birds.std)


###################################################
### code chunk number 38: LinearSweaveFile.Rnw:621-632
###################################################
fit.m1<-lm(BRCR~ls +stream.den + sub.lat + s.contag,data=birds.std)
fit.m2<-lm(BRCR~ls +stream.den + s.contag,data=birds.std)
fit.m3<-lm(BRCR~ls,data=birds.std)
fit.m4<-lm(BRCR~s.mps,data=birds.std)
fit.m5<-lm(BRCR~stream.den,data=birds.std)
fit.m6<-lm(BRCR~sub.lat,data=birds.std)
fit.m7<-lm(BRCR~ls*sub.lat + stream.den + s.contag,data=birds.std)
fit.m8<-lm(BRCR~ls + stream.den + sub.lat + I(sub.lat^2) + s.contag,
     data=birds.std)
fitm.AIC<-AIC(fit.m1,fit.m2,fit.m3,fit.m4,fit.m5,fit.m6,fit.m7,fit.m8)
fitm.AIC[order(fitm.AIC[,2]),]


###################################################
### code chunk number 39: LinearSweaveFile.Rnw:639-640
###################################################
summary(fit.m7); summary(fit.m8); summary(fit.m1)


###################################################
### code chunk number 40: LinearSweaveFile.Rnw:645-646
###################################################
anova(fit.m8,fit.m2,test='Chi')


###################################################
### code chunk number 41: LinearSweaveFile.Rnw:657-660
###################################################
model.list<-list(fit.m1,fit.m2,fit.m3,fit.m4,fit.m5,fit.m6,fit.m7,fit.m8)
model.ave<-model.avg(model.list)
summary(model.ave)


###################################################
### code chunk number 42: LinearSweaveFile.Rnw:672-674
###################################################
new.obs<-data.frame(ls=80,sub.lat=4930120,stream.den=43,s.contag=81,s.mps=263)
predict(fit.a4,newdata=new.obs,interval='prediction')


###################################################
### code chunk number 43: LinearSweaveFile.Rnw:679-681
###################################################
new.obs<-data.frame(ls=80,sub.lat=4930120,stream.den=23,s.contag=81,s.mps=263)
predict(fit.a4,newdata=new.obs,interval='prediction')


###################################################
### code chunk number 44: LinearSweaveFile.Rnw:688-690
###################################################
birds.new<-read.csv('birds.new.csv',header=TRUE)
predict(fit.a4,newdata=birds.new,interval='prediction')


###################################################
### code chunk number 45: LinearSweaveFile.Rnw:697-700
###################################################
par(mfrow=c(2,2))
termplot(fit.a4,se=TRUE,partial.resid=TRUE)
par(mfrow=c(1,1))


###################################################
### code chunk number 46: LinearSweaveFile.Rnw:707-712
###################################################
birds.mean<-apply(birds[,c(4,8,10,11,13)],2,mean)
birds.sd<-apply(birds[,c(4,8,10,11,13)],2,sd)
birds.new.std<-as.data.frame(scale(birds.new[,3:7],center=birds.mean,
     scale=birds.sd))
predict(model.ave,newdata=birds.new.std,interval='prediction')


###################################################
### code chunk number 47: LinearSweaveFile.Rnw:719-721
###################################################
apply(birds[,c(4,8,10,11,13)],2,range)
apply(birds.new[,3:7],2,range)


###################################################
### code chunk number 48: LinearSweaveFile.Rnw:729-734
###################################################
birds.cov<-cov(birds[,c(4,8,10,11,13)])
birds.md<-mahalanobis(birds[,c(4,8,10,11,13)],center=birds.mean,cov=birds.cov)
plot(density(birds.md))
birds.md.new<-mahalanobis(birds.new[,3:7],center=birds.mean,cov=birds.cov)
rug(birds.md.new,col='red',lwd=3)


###################################################
### code chunk number 49: LinearSweaveFile.Rnw:757-768
###################################################
fit.LN<-lm(BRCR~ls + stream.den + sub.lat + s.contag,
     data=birds[birds$basin!='D',])
fit.DN<-lm(BRCR~ls + stream.den + sub.lat + s.contag,
     data=birds[birds$basin!='L',])
fit.DL<-lm(BRCR~ls + stream.den + sub.lat + s.contag,
     data=birds[birds$basin!='N',])
pred.D<-predict(fit.LN,newdata=birds[birds$basin=='D',])
pred.L<-predict(fit.LN,newdata=birds[birds$basin=='L',])
pred.N<-predict(fit.LN,newdata=birds[birds$basin=='N',])
pred.DLN<-c(pred.D,pred.L,pred.N)
epi.ccc(birds$BRCR,pred.DLN)$rho.c


###################################################
### code chunk number 50: LinearSweaveFile.Rnw:778-780
###################################################
plot(birds$BRCR,pred.DLN,xlab='Observed',ylab='Predicted')
abline(a=0,b=1)


